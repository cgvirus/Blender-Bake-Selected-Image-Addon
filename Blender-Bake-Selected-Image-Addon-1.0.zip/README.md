# Blender-Bake-Selected-Image-Addon
Blender Bake Selected Image Addon to bake texture map easily in Blender 2.8 and above
